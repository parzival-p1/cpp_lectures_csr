#include <iostream>
#include "Simulator.h"

using namespace std;

int main()
{
    Simulator simulator; //1. construye el obj
    simulator.runTest(); // 2. manda llamar run
    return 0;
}

