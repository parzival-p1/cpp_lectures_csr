#include <stdio.h>
#include "interface.h"

int main()
{
    Init();
    return 0;
}
